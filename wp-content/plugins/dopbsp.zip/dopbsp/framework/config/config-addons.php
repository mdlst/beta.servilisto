<?php

/*
 * Title                   : DOT Framework
 * File                    : framework/config/config-addons.php
 * Author                  : Dot on Paper
 * Copyright               : © 2019 Dot on Paper
 * Website                 : https://dotonpaper.net
 * Description             : Framework add-ons config file.
 */

global $dot_addons;

$dot_addons = array('stripe');