<?php

/*
 * Title                   : Pinpoint Booking System
 * File                    : application/translation/en/text-templates.php
 * Author                  : Dot on Paper
 * Copyright               : © 2017 Dot on Paper
 * Website                 : https://www.dotonpaper.net
 * Description             : Templates english text.
 */

    global $dot_text;

    $dot_text['TEMPLATES_PARENT'] = 'Templates';
                
    $dot_text['TEMPLATES_TITLE'] = 'Templates';